def two():
    print("TWO")
