def one():
    return "ONE"
