import setuptools

setuptools.setup(
    name='mefulu',  # Имя пакета
    version='0.0.1',  # Версия пакета
    author='Zagumennov U.I.',
    author_email='your@domain.com',
    description='My Package',
    packages=setuptools.find_packages(),
)
